export interface AboutMovie {
     movieId: number;
     movieImage: string;
     movieName: string;
  
     movieGenre: string;
     movieLanguage: string;
     movieDescription: string;
     movieRating: number;
     movieDate: Date;
}
