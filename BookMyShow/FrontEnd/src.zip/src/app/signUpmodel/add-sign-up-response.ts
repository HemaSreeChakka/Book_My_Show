export interface AddSignUpResponse {

userName:string,
userEmail:string,
userMobile:string,
password:string,
confirmPassword:string




}
