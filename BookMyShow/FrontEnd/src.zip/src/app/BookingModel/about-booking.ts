export interface AboutBooking {

     ticketId: number;
     transactionMode: string;
     transactionStatus: string;
     totalCost: number;
     seats:number;
     bookingDate: Date;
    
}
