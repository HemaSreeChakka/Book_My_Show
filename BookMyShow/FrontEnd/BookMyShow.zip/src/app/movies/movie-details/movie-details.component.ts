
import { Component, OnInit } from '@angular/core';
import { AboutMovie } from 'src/app/about-movie';
import { MovieService } from 'src/app/services/movie.service';
import { ActivatedRoute, Router } from '@angular/router';

@Component({
  selector: 'app-movie-details',
  templateUrl: './movie-details.component.html',
  styleUrls: ['./movie-details.component.css']
})
export class MovieDetailsComponent implements OnInit {
  details!:AboutMovie;
  movieId!: number;
  constructor( private movieService:MovieService,
    private actRouter: ActivatedRoute
    ) { }
  



  ngOnInit(): void {

   
    /*this.userService.getUser().subscribe((data: UserDetails) => {
      console.log(data);
      this.details = data;
     
    }); */

    this.movieId = this.actRouter.snapshot.params['id'];
    console.log(this.movieId);
    this.movieService.getMovieId(this.movieId).subscribe((data: AboutMovie) => {
      this.details = data;
     
    });



   
  }

}
