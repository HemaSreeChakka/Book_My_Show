export interface AboutSignUp {
    userName:string,
userEmail:string,
userMobile:string,
password:string,
confirmPassword:string

}
