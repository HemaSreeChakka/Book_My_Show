export interface AboutBooking {

     transactionId: number;
     transactionMode: string;
     transactionStatus: string;
     totalCost: number;
     seats:number;
     bookingDate: Date;
    
}
