export interface AddBookingResponse {
transactionId:number,
    transactionMode: string;
transactionStatus:string;
    seats:number;
    totalCost:number;
    bookingDate: Date;
}
