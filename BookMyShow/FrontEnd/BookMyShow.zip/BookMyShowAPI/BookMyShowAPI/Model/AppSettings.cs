﻿namespace BookMyShowAPI.Model
{
    public class AppSettings
    {
        public string Key { get; set; }
    }
}
